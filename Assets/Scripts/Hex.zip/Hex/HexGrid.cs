﻿using UnityEngine;
using System.Collections;

public class HexGrid : MonoBehaviour {
	[SerializeField]private GameObject _hexagon;
	[SerializeField]private float _gridSizeX;
	[SerializeField]private float _gridSizeY;
	private CalculateHex _hex;
	private Vector3 _position;


	private void Start () {
		for (int x = 0; x < _gridSizeX; x++) {
			for (int z = 0; z < _gridSizeY; z++) {
				
				GameObject newHex = Instantiate (_hexagon, Vector3.zero, Quaternion.identity) as GameObject;
				_hex = newHex.GetComponent<CalculateHex> ();
				_position = new Vector3 ((x + z * 0.5f - z / 2) * _hex.Width - _gridSizeX / 2, 0, z * _hex.Height * 0.75f - _gridSizeY / 2);
				newHex.transform.position = _position;
				_hex.CreateHexagon (_position);
			}
		}
			
	}
}
