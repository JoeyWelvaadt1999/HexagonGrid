﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer), typeof(CalculateHex))]
public class HexagonMesh : MonoBehaviour {
	private Mesh _mesh;
	private CalculateHex _hex;
	private List<Vector3> _vertices = new List<Vector3>();
	private List<int> _triangles = new List<int>();
	private List<Vector2> _uvs = new List<Vector2>();

	private void Start() {
		_mesh = GetComponent<MeshFilter> ().mesh;
		_hex = GetComponent<CalculateHex> ();
		_vertices = _hex.Points;
		Triangulate ();
		UVMapping ();
		_mesh.Clear ();
		_mesh.Optimize ();
		_mesh.vertices = _vertices.ToArray ();
		_mesh.triangles = _triangles.ToArray ();
		_mesh.uv = _uvs.ToArray ();
		_mesh.RecalculateNormals ();		
		transform.position = new Vector3(0, 0, 0);
	}
		

	private void Triangulate() {
		for (int i = 0; i < 6; i++) {
			_triangles.Add (0);
			_triangles.Add (i + 1);
			if (i + 2 > 6) {
				_triangles.Add (1);
			} else {
				_triangles.Add (i + 2);
			}
		}
	}

	private void UVMapping() {
		_uvs.Add (new Vector2(transform.position.x, transform.position.z));
		_uvs.Add (new Vector2(0,0.25f));
		_uvs.Add (new Vector2(0,0.75f));
		_uvs.Add (new Vector2(0.5f,1));
		_uvs.Add (new Vector2(1,0.75f));
		_uvs.Add (new Vector2(1,0.25f));
		_uvs.Add (new Vector2(0.5f,0));
	}

}
